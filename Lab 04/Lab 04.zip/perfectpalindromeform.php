<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Nguyen Anh Vu"/>
<title>TITLE</title>
</head>
<body>
    <h1>Lab04 Task 2 - Perfect Palindrome</h1>
    <form action="perfectpalindrome.php" method="post">
        String: <input type="text" name="word"><br>
        <input type="submit" value="Check for Perfect Palindrome">
    </form>
</body>
</html>