<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Nguyen Anh Vu"/>
<title>TITLE</title>
</head>
<body>
    <h1>Lab04 Task 3 - Standard Palindrome</h1>
    <form action="standardpalindrome.php" method="post">
        String: <input type="text" name="string"><br>
        <input type="submit" value="Check for Standard Palindrome">
    </form>
</body>
</html>