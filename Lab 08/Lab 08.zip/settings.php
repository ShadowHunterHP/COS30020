<?php
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s103806007";
    $pswd = "221103";
    $dbnm = "s103806007_db";
?>
