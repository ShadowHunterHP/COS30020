<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Nguyen Anh Vu" />
    <title>TITLE</title>
</head>

<body>
    <h1>Web Programming - Lab 08</h1>
    <h2>Home Page</h2>
    <a href="member_add_form.php">Add New Member</a>
    <a href="member_display.php">Display All Member</a>
    <a href="member_search.php">Search Member</a>
</body>

</html>
